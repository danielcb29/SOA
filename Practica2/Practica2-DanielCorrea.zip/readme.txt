#readme.txt

Arquitecturas Orientadas a Serivicios 
Practica 2 
Daniel Correa Barrios

Adjunto se encuentra el proyecto eclipse y el informe. 