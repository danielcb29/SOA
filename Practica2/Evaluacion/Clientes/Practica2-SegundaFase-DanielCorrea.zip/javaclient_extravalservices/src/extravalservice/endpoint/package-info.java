@javax.xml.bind.annotation.XmlSchema(namespace = "http://endpoint.extravalservice/")
package extravalservice.endpoint;
