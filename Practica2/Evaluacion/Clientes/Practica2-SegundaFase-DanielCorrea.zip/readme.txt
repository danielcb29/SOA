#readme.txt

Daniel Correa Barrios
Arquitecturas Orientadas a Servicios
Practica 2, segunda fase

Se adjunta 1 informe, un xml con cliente de SoapUI y un proyecto Java con una aplicación cliente que funciona para los 3 servicios evaluados